function sigma = fwd_sigma(t,dsigma)
    sigma = dsigma*t;
end