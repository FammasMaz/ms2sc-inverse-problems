main files are `Project.m` in directory `main` and `secondary`
